
clear; clc; close all;
fis = mamfis('Name', 'AkilliKavsakSistemi');
fis = addInput(fis, [0 100], 'Name', 'KirmiziIsikKuyrugu');
fis = addMF(fis, 'KirmiziIsikKuyrugu', 'trimf', [-50 0 50], 'Name', 'Az');
fis = addMF(fis, 'KirmiziIsikKuyrugu', 'trimf', [25 50 75], 'Name', 'Orta');
fis = addMF(fis, 'KirmiziIsikKuyrugu', 'trapmf', [50 100 150 150], 'Name', 'Cok');
fis = addInput(fis, [0 100], 'Name', 'GelenTrafikYogunlugu');
fis = addMF(fis, 'GelenTrafikYogunlugu', 'trimf', [-50 0 50], 'Name', 'Az');
fis = addMF(fis, 'GelenTrafikYogunlugu', 'trimf', [25 50 75], 'Name', 'Orta');
fis = addMF(fis, 'GelenTrafikYogunlugu', 'trapmf', [50 100 150 150], 'Name', 'Cok');
fis = addOutput(fis, [10 60], 'Name', 'YesilIsikSuresi');
fis = addMF(fis, 'YesilIsikSuresi', 'trimf', [0 10 30], 'Name', 'Kisa');
fis = addMF(fis, 'YesilIsikSuresi', 'trimf', [20 35 50], 'Name', 'Normal');
fis = addMF(fis, 'YesilIsikSuresi', 'trapmf', [40 60 80 80], 'Name', 'Uzun');
kurallar = [
    1 1 1 1 1; % 1. Kural
    1 2 2 1 1; % 2. Kural
    1 3 3 1 1; % 3. Kural
    2 1 1 1 1; % 4. Kural
    2 2 2 1 1; % 5. Kural
    2 3 3 1 1; % 6. Kural
    3 1 1 1 1; % 7. Kural
    3 2 1 1 1; % 8. Kural
    3 3 2 1 1  % 9. Kural
];

fis = addRule(fis, kurallar);
test_kuyruk = 50.6;
test_gelen = 93.4;
hesaplanan_sure = evalfis(fis, [test_kuyruk, test_gelen]);
fprintf('--- Kavşak Durumu ---\n');
fprintf('Kırmızıda Bekleyen Yoğunluğu : %%%.1f\n', test_kuyruk);
fprintf('Gelen Araç Yoğunluğu         : %%%.1f\n', test_gelen);
fprintf('>> Atanan Yeşil Işık Süresi  : %.2f Saniye\n', hesaplanan_sure);
figure('Name', 'Karar Yüzeyi (Surface)');
gensurf(fis);
title('Girişlere Göre Yeşil Işık Süresi Değişimi');
xlabel('Kuyruk Yoğunluğu');
ylabel('Gelen Trafik Yoğunluğu');
zlabel('Yeşil Işık Süresi (sn)');
ruleview(fis);